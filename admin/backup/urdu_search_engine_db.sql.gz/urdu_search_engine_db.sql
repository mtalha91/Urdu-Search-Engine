# Table backup from Sphider
# Creation date: 01-Aug-2012 08:46
# Database: 
# MySQL Server version: 5.1.36-community-log

# Valid end of backup from Sphider backup
