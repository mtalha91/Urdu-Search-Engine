# Table backup from Urdu Search Engine
# Creation date: 25-Oct-2012 08:09
# Database: 
# MySQL Server version: 5.1.36-community-log

# Valid end of backup from Urdu Search Engine backup
